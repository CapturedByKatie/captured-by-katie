CAPTURED BY KATIE WEBSITE

This folder contains:
- index.html — your website
- images/ — the 10 uploaded portfolio photos

Before publishing:
1. Open index.html and replace YOUR-EMAIL-HERE@example.com with your real business email.
2. Replace the About text with your own story.
3. Review the session prices and change them if needed.
4. Add your Instagram link if you want one.

For a free public website, upload these files to a GitHub repository and enable GitHub Pages.
For a custom address such as capturedbykatie.com, buy the domain and connect it under the repository's Pages settings.
